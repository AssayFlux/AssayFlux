# AssayFlux Language Specification Status

**Language:** AssayFlux Scientific Systems  
**Short name:** AssayFlux  
**Source extension:** `.af`  
**Project version:** 0.2.0

## Status definitions

- **Implemented/tested:** covered by automated tests in this repository.
- **Implemented, limited tests:** code exists, but the tested behavior is narrower than a production language guarantee.
- **Adapter present:** adapter source exists; this does not establish runtime availability or compatibility.
- **Planned:** not implemented as a stable feature.

## Core language status

| Feature | Status | Notes |
|---|---|---|
| `.af` source files and CLI | Implemented/tested | `assayflux path/to/file.af` |
| Comments and quoted strings | Implemented | `#`, single and double quotes; no backticks |
| Integer and decimal literals | Implemented/tested | Numeric edge cases still need broader coverage |
| Boolean literals `true`, `false` | Implemented/tested | Runtime values are Python booleans |
| Variables and assignments | Implemented/tested | Dynamic values; no static type system |
| `constant NAME = value` | Implemented/tested | Prevents rebinding; does not freeze mutable objects |
| `show expression` | Implemented/tested | Writes to stdout and interpreter output collection |
| `if` / `otherwise` / `else` / `end` | Implemented/tested | `otherwise` takes a condition |
| `repeat condition` / `end` | Implemented/tested | Condition is checked before each iteration; loop safety cap exists |
| `stop` / `skip` | Implemented/tested | Nearest active repeat loop |
| `f.name(parameters)` / `return` | Implemented/tested | Basic function calls and return behavior |
| `app "Application Name"` | Implemented/tested | Stores interpreter metadata; not an application packager |
| Expression statements | Implemented/tested | Useful for calls whose result is ignored |
| Python module imports | Implemented/tested | Runs with host-process permissions; not sandboxed |
| `input()` | Implemented | Reads from standard input |
| Lists, dictionaries, indexing, classes | Not yet stable | Add only with a specification and tests |
| Exception handling in AssayFlux syntax | Planned | Host exceptions are normalized only in limited cases |
| User module/package system | Planned | Python imports are not an AssayFlux package manager |
| Static type checker / bytecode VM | Planned | Not required for the initial tree-walking interpreter |

## Interoperability status

Adapter source files exist for multiple languages. Each runtime must be checked independently. An adapter file, successful process launch, or installed compiler alone does not establish a supported integration.

| Technology | Intended integration | Status rule |
|---|---|---|
| Python | Import modules / execute Python source through adapter | Core Python import and adapter tests exist; not sandboxed |
| JavaScript / TypeScript | Runtime adapter; browser for web front end | Verify runtime, compilation, and value conventions per environment |
| C / C++ / Rust / Go | Compiler or native-library integration | Compiler availability and linking are platform-specific |
| Java / Kotlin / Scala / C# / F# | JVM or .NET execution / library bridge | Runtime and bridge must be installed and tested |
| R / Julia / Fortran | Scientific-computing runtimes | Runtime and package availability must be checked |
| Lua / Ruby / PHP / Perl and others | External runtime adapter | Must pass language-specific integration tests |
| SQL | Database driver and configured connection | Planned as a database capability, not a general source interpreter |
| HTML / CSS | Web assets rendered by browser/WebView | Not interpreted as general-purpose code by AssayFlux |

## Release principle

Only claim a feature as supported when the implementation, tests, dependencies, compatibility limits, and security implications are documented. The current release is an early-stage developer foundation, not a production-ready multi-language platform.
